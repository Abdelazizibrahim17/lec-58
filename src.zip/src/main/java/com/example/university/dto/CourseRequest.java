package com.example.university.dto;
import jakarta.validation.constraints.*;
public record CourseRequest(@NotBlank @Size(max = 200) String title, @Size(max = 2000) String description) {}

