package com.example.university.dto;

public record CourseBasicResponse(Long id, String title, String description, InstructorBasicResponse instructor) {}

