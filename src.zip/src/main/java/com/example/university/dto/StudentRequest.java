package com.example.university.dto;
import jakarta.validation.constraints.*;
public record StudentRequest(@NotBlank @Size(max = 100) String name, @NotBlank @Email @Size(max = 254) String email) {}

