package com.example.university.dto;
import java.util.List;
public record CourseResponse(Long id, String title, String description, InstructorBasicResponse instructor, List<StudentBasicResponse> students) {}

