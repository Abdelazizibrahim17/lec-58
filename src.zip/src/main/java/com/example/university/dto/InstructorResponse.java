package com.example.university.dto;
import java.util.List;
public record InstructorResponse(Long id, String name, String email, List<CourseResponse> courses) {}

