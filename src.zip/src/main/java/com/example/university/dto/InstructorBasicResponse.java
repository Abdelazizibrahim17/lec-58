package com.example.university.dto;

public record InstructorBasicResponse(Long id, String name, String email) {}

