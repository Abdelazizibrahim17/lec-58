package com.example.university.dto;

public record StudentBasicResponse(Long id, String name, String email) {}

