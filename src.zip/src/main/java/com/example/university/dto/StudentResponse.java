package com.example.university.dto;
import java.util.List;
public record StudentResponse(Long id, String name, String email, List<CourseBasicResponse> courses) {}

