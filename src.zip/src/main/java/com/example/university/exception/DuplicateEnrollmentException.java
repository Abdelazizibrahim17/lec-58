package com.example.university.exception;
public class DuplicateEnrollmentException extends RuntimeException {
    public DuplicateEnrollmentException(Long studentId, Long courseId) {
        super("Student " + studentId + " is already registered in course " + courseId);
    }
}

