package com.example.university.entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import java.util.LinkedHashSet;
import java.util.Set;
@Entity
@Table(name = "instructors")
@Getter @Setter @NoArgsConstructor
public class Instructor {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "instructor_generator")
    @SequenceGenerator(name = "instructor_generator", sequenceName = "instructor_seq", allocationSize = 1)
    private Long id;
    @Column(nullable = false, length = 100)
    private String name;
    @Column(nullable = false, length = 254)
    private String email;
    
    @OneToMany(mappedBy = "instructor")
    private Set<Course> courses = new LinkedHashSet<>();
}

