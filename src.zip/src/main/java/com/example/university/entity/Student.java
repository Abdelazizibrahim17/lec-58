package com.example.university.entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import java.util.LinkedHashSet;
import java.util.Set;
@Entity
@Table(name = "students")
@Getter @Setter @NoArgsConstructor
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "student_generator")
    @SequenceGenerator(name = "student_generator", sequenceName = "student_seq", allocationSize = 1)
    private Long id;
    @Column(nullable = false, length = 100)
    private String name;
    @Column(nullable = false, length = 254)
    private String email;
    
    @ManyToMany
    @JoinTable(name = "student_course",
        joinColumns = @JoinColumn(name = "student_id", nullable = false, foreignKey = @ForeignKey(name = "fk_sc_student")),
        inverseJoinColumns = @JoinColumn(name = "course_id", nullable = false, foreignKey = @ForeignKey(name = "fk_sc_course")),
        uniqueConstraints = @UniqueConstraint(name = "uk_student_course", columnNames = {"student_id", "course_id"}))
    private Set<Course> courses = new LinkedHashSet<>();
    public void enroll(Course course) {
        courses.add(course);
        course.getStudents().add(this);
    }
}

