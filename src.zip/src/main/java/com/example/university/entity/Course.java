package com.example.university.entity;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;
import java.util.LinkedHashSet;
import java.util.Set;
@Entity
@Table(name = "courses")
@Getter @Setter @NoArgsConstructor
public class Course {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "course_generator")
    @SequenceGenerator(name = "course_generator", sequenceName = "course_seq", allocationSize = 1)
    private Long id;
    @Column(nullable = false, length = 200)
    private String title;
    @Column(length = 2000)
    private String description;
    
    @ManyToMany(mappedBy = "courses")
    private Set<Student> students = new LinkedHashSet<>();
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "instructor_id", foreignKey = @ForeignKey(name = "fk_course_instructor"))
    private Instructor instructor;
    public void assignInstructor(Instructor next) {
        if (instructor != null) instructor.getCourses().remove(this);
        instructor = next;
        next.getCourses().add(this);
    }
}

