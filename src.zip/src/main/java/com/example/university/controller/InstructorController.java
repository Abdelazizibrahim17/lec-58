package com.example.university.controller;
import com.example.university.dto.*;
import com.example.university.service.InstructorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;
@RestController
@RequestMapping("/api/instructors")
@RequiredArgsConstructor
public class InstructorController {
    private final InstructorService service;
    @PostMapping
    public ResponseEntity<InstructorResponse> create(@Valid @RequestBody InstructorRequest request) {
        InstructorResponse response = service.create(request);
        return ResponseEntity.created(URI.create("/api/instructors/" + response.id())).body(response);
    }
    @GetMapping
    public List<InstructorResponse> findAll() { return service.findAll(); }
    @GetMapping("/{id}")
    public InstructorResponse findById(@PathVariable Long id) { return service.findById(id); }
    @GetMapping("/{id}/courses")
    public List<CourseResponse> courses(@PathVariable Long id) { return service.courses(id); }
}

