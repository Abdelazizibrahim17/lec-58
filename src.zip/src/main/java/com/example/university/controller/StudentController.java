package com.example.university.controller;
import com.example.university.dto.*;
import com.example.university.service.StudentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;
@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
public class StudentController {
    private final StudentService service;
    @PostMapping
    public ResponseEntity<StudentResponse> create(@Valid @RequestBody StudentRequest request) {
        StudentResponse response = service.create(request);
        return ResponseEntity.created(URI.create("/api/students/" + response.id())).body(response);
    }
    @GetMapping
    public List<StudentResponse> findAll() { return service.findAll(); }
    @GetMapping("/{id}")
    public StudentResponse findById(@PathVariable Long id) { return service.findById(id); }
    @PostMapping("/{studentId}/courses/{courseId}")
    public StudentResponse register(@PathVariable Long studentId, @PathVariable Long courseId) {
        return service.register(studentId, courseId);
    }
}

