package com.example.university.controller;
import com.example.university.dto.*;
import com.example.university.service.CourseService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.net.URI;
import java.util.List;
@RestController
@RequestMapping("/api/courses")
@RequiredArgsConstructor
public class CourseController {
    private final CourseService service;
    @PostMapping
    public ResponseEntity<CourseResponse> create(@Valid @RequestBody CourseRequest request) {
        CourseResponse response = service.create(request);
        return ResponseEntity.created(URI.create("/api/courses/" + response.id())).body(response);
    }
    @GetMapping
    public List<CourseResponse> findAll() { return service.findAll(); }
    @GetMapping("/{id}")
    public CourseResponse findById(@PathVariable Long id) { return service.findById(id); }
    @PutMapping("/{courseId}/instructor/{instructorId}")
    public CourseResponse assignInstructor(@PathVariable Long courseId, @PathVariable Long instructorId) {
        return service.assignInstructor(courseId, instructorId);
    }
}

