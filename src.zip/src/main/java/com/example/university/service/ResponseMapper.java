package com.example.university.service;
import com.example.university.dto.*;
import com.example.university.entity.*;
import org.springframework.stereotype.Component;
import java.util.Comparator;
@Component
public class ResponseMapper {
    public InstructorBasicResponse instructorBasic(Instructor i) {
        return i == null ? null : new InstructorBasicResponse(i.getId(), i.getName(), i.getEmail());
    }
    public CourseBasicResponse courseBasic(Course c) {
        return new CourseBasicResponse(c.getId(), c.getTitle(), c.getDescription(), instructorBasic(c.getInstructor()));
    }
    public StudentBasicResponse studentBasic(Student s) {
        return new StudentBasicResponse(s.getId(), s.getName(), s.getEmail());
    }
    public StudentResponse student(Student s) {
        return new StudentResponse(s.getId(), s.getName(), s.getEmail(), s.getCourses().stream()
            .sorted(Comparator.comparing(Course::getId)).map(this::courseBasic).toList());
    }
    public CourseResponse course(Course c) {
        return new CourseResponse(c.getId(), c.getTitle(), c.getDescription(), instructorBasic(c.getInstructor()),
            c.getStudents().stream().sorted(Comparator.comparing(Student::getId)).map(this::studentBasic).toList());
    }
    public InstructorResponse instructor(Instructor i) {
        return new InstructorResponse(i.getId(), i.getName(), i.getEmail(), i.getCourses().stream()
            .sorted(Comparator.comparing(Course::getId)).map(this::course).toList());
    }
}

