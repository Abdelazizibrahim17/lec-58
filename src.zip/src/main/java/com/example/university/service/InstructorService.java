package com.example.university.service;
import com.example.university.dto.*;
import com.example.university.entity.*;
import com.example.university.repository.*;
import com.example.university.exception.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Sort;
import java.util.List;
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class InstructorService {
    private final InstructorRepository repository;
    private final ResponseMapper mapper;
    
    public List<InstructorResponse> findAll() {
        return repository.findAll(Sort.by("id")).stream().map(mapper::instructor).toList();
    }
    public InstructorResponse findById(Long id) { return mapper.instructor(require(id)); }
    private Instructor require(Long id) {
        return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Instructor", id));
    }
    @Transactional
    public InstructorResponse create(InstructorRequest request) {
        Instructor entity = new Instructor();
        entity.setName(request.name());
        entity.setEmail(request.email());
        return mapper.instructor(repository.save(entity));
    }
    public List<CourseResponse> courses(Long id) {
        return mapper.instructor(require(id)).courses();
    }
}

