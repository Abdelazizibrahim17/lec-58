package com.example.university.service;
import com.example.university.dto.*;
import com.example.university.entity.*;
import com.example.university.repository.*;
import com.example.university.exception.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Sort;
import java.util.List;
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class StudentService {
    private final StudentRepository repository;
    private final ResponseMapper mapper;
    private final CourseRepository courseRepository;
    public List<StudentResponse> findAll() {
        return repository.findAll(Sort.by("id")).stream().map(mapper::student).toList();
    }
    public StudentResponse findById(Long id) { return mapper.student(require(id)); }
    private Student require(Long id) {
        return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Student", id));
    }
    @Transactional
    public StudentResponse create(StudentRequest request) {
        Student entity = new Student();
        entity.setName(request.name());
        entity.setEmail(request.email());
        return mapper.student(repository.save(entity));
    }
    @Transactional
    public StudentResponse register(Long studentId, Long courseId) {
        Student student = repository.findByIdForEnrollment(studentId)
            .orElseThrow(() -> new ResourceNotFoundException("Student", studentId));
        Course course = courseRepository.findById(courseId)
            .orElseThrow(() -> new ResourceNotFoundException("Course", courseId));
        if (student.getCourses().contains(course)) throw new DuplicateEnrollmentException(studentId, courseId);
        student.enroll(course);
        return mapper.student(student);
    }
}

