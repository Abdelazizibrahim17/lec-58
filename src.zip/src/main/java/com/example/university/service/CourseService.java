package com.example.university.service;
import com.example.university.dto.*;
import com.example.university.entity.*;
import com.example.university.repository.*;
import com.example.university.exception.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Sort;
import java.util.List;
@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CourseService {
    private final CourseRepository repository;
    private final ResponseMapper mapper;
    private final InstructorRepository instructorRepository;
    public List<CourseResponse> findAll() {
        return repository.findAll(Sort.by("id")).stream().map(mapper::course).toList();
    }
    public CourseResponse findById(Long id) { return mapper.course(require(id)); }
    private Course require(Long id) {
        return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Course", id));
    }
    @Transactional
    public CourseResponse create(CourseRequest request) {
        Course entity = new Course();
        entity.setTitle(request.title());
        entity.setDescription(request.description());
        return mapper.course(repository.save(entity));
    }
    @Transactional
    public CourseResponse assignInstructor(Long courseId, Long instructorId) {
        Course course = require(courseId);
        Instructor instructor = instructorRepository.findById(instructorId)
            .orElseThrow(() -> new ResourceNotFoundException("Instructor", instructorId));
        course.assignInstructor(instructor);
        return mapper.course(course);
    }
}

