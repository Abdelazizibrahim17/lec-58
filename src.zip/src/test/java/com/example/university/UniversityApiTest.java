package com.example.university;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.dao.DataIntegrityViolationException;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class UniversityApiTest {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;
    @Autowired JdbcTemplate jdbc;
    @BeforeEach void clean() {
        jdbc.update("delete from student_course");
        jdbc.update("delete from courses");
        jdbc.update("delete from students");
        jdbc.update("delete from instructors");
    }
    long create(String resource, String body) throws Exception {
        MvcResult result = mvc.perform(post("/api/" + resource).contentType("application/json").content(body))
            .andExpect(status().isCreated()).andExpect(header().exists("Location")).andReturn();
        return json.readTree(result.getResponse().getContentAsString()).get("id").asLong();
    }
    long student() throws Exception { return create("students", "{\"name\":\"John Doe\",\"email\":\"john@example.com\"}"); }
    long course() throws Exception { return create("courses", "{\"title\":\"Java Programming\",\"description\":\"Java fundamentals\"}"); }
    long instructor() throws Exception { return create("instructors", "{\"name\":\"Dr. Smith\",\"email\":\"smith@example.com\"}"); }

    @Test void completeWorkflowPersistsRelationshipsAndReturnsFiniteJson() throws Exception {
        long s = student(), c = course(), i = instructor();
        mvc.perform(get("/api/courses/" + c)).andExpect(status().isOk()).andExpect(jsonPath("$.instructor").isEmpty());
        mvc.perform(put("/api/courses/" + c + "/instructor/" + i))
            .andExpect(status().isOk()).andExpect(jsonPath("$.instructor.id").value(i));
        mvc.perform(post("/api/students/" + s + "/courses/" + c))
            .andExpect(status().isOk()).andExpect(jsonPath("$.courses[0].instructor.id").value(i));
        mvc.perform(get("/api/students/" + s)).andExpect(status().isOk())
            .andExpect(jsonPath("$.courses[0].title").value("Java Programming"))
            .andExpect(jsonPath("$.courses[0].students").doesNotExist());
        mvc.perform(get("/api/courses/" + c)).andExpect(status().isOk())
            .andExpect(jsonPath("$.students[0].id").value(s))
            .andExpect(jsonPath("$.students[0].courses").doesNotExist());
        mvc.perform(get("/api/instructors/" + i)).andExpect(status().isOk())
            .andExpect(jsonPath("$.courses[0].students[0].id").value(s));
        mvc.perform(get("/api/instructors/" + i + "/courses")).andExpect(status().isOk())
            .andExpect(jsonPath("$[0].students[0].id").value(s));
        for (String resource : new String[]{"students", "courses", "instructors"}) {
            mvc.perform(get("/api/" + resource)).andExpect(status().isOk()).andExpect(jsonPath("$.length()").value(1));
        }
        assertEquals(1, jdbc.queryForObject("select count(*) from student_course where student_id=? and course_id=?", Integer.class, s, c));
        mvc.perform(post("/api/students/" + s + "/courses/" + c)).andExpect(status().isBadRequest());
        assertEquals(1, jdbc.queryForObject("select count(*) from student_course", Integer.class));
    }
    @Test void manyStudentsCanEnrollInManyCourses() throws Exception {
        long firstStudent = student(), secondStudent = student();
        long firstCourse = course(), secondCourse = course();
        for (long s : new long[]{firstStudent, secondStudent}) {
            for (long c : new long[]{firstCourse, secondCourse}) {
                mvc.perform(post("/api/students/" + s + "/courses/" + c)).andExpect(status().isOk());
            }
        }
        mvc.perform(get("/api/students/" + firstStudent)).andExpect(jsonPath("$.courses.length()").value(2));
        mvc.perform(get("/api/courses/" + firstCourse)).andExpect(jsonPath("$.students.length()").value(2));
        assertEquals(4, jdbc.queryForObject("select count(*) from student_course", Integer.class));
    }
    @Test void reassignmentUpdatesBothInstructorViews() throws Exception {
        long c = course(), first = instructor(), second = instructor();
        mvc.perform(put("/api/courses/" + c + "/instructor/" + first)).andExpect(status().isOk());
        mvc.perform(put("/api/courses/" + c + "/instructor/" + second)).andExpect(status().isOk());
        mvc.perform(get("/api/instructors/" + first + "/courses")).andExpect(jsonPath("$.length()").value(0));
        mvc.perform(get("/api/instructors/" + second + "/courses")).andExpect(jsonPath("$[0].id").value(c));
    }
    @ParameterizedTest
    @ValueSource(strings={"students", "courses", "instructors", "instructors/999999/courses"})
    void missingResourcesReturn404(String resource) throws Exception {
        String path = resource.contains("/") ? resource : resource + "/999999";
        mvc.perform(get("/api/" + path)).andExpect(status().isNotFound()).andExpect(jsonPath("$.status").value(404));
    }
    @Test void missingRelationshipTargetsReturn404WithoutChanges() throws Exception {
        long s = student(), c = course(), i = instructor();
        mvc.perform(post("/api/students/" + s + "/courses/999999")).andExpect(status().isNotFound());
        mvc.perform(post("/api/students/999999/courses/" + c)).andExpect(status().isNotFound());
        mvc.perform(put("/api/courses/" + c + "/instructor/999999")).andExpect(status().isNotFound());
        mvc.perform(put("/api/courses/999999/instructor/" + i)).andExpect(status().isNotFound());
        assertEquals(0, jdbc.queryForObject("select count(*) from student_course", Integer.class));
    }
    @ParameterizedTest @ValueSource(strings={"students", "instructors"})
    void invalidPeopleReturn400(String resource) throws Exception {
        mvc.perform(post("/api/" + resource).contentType("application/json")
            .content("{\"name\":\" \",\"email\":\"invalid\"}"))
            .andExpect(status().isBadRequest()).andExpect(jsonPath("$.errors.name").exists())
            .andExpect(jsonPath("$.errors.email").exists());
    }
    @Test void invalidCourseAndMalformedRequestsReturn400() throws Exception {
        mvc.perform(post("/api/courses").contentType("application/json").content("{\"title\":\"\"}"))
            .andExpect(status().isBadRequest());
        mvc.perform(post("/api/students").contentType("application/json").content("{"))
            .andExpect(status().isBadRequest());
        mvc.perform(get("/api/students/abc")).andExpect(status().isBadRequest());
    }
    @Test void schemaEnforcesJoinUniquenessAndForeignKeys() throws Exception {
        long s = student(), c = course();
        jdbc.update("insert into student_course(student_id,course_id) values (?,?)", s, c);
        assertThrows(DataIntegrityViolationException.class, () ->
            jdbc.update("insert into student_course(student_id,course_id) values (?,?)", s, c));
        assertThrows(DataIntegrityViolationException.class, () ->
            jdbc.update("insert into student_course(student_id,course_id) values (?,?)", s, 999999));
        assertThrows(DataIntegrityViolationException.class, () ->
            jdbc.update("insert into student_course(student_id,course_id) values (?,?)", 999999, c));
        assertThrows(DataIntegrityViolationException.class, () ->
            jdbc.update("update courses set instructor_id=999999 where id=?", c));
    }
}
